<?php

$lang['Version']     = 'Version';
$lang['Description'] = 'Description';
$lang['changelog']   = array(

// AN ERROR EDITING THIS FILE WILL RETURN A PHP ERROR IN YOUR CHANGELOG PAGE
// EDIT FROM HERE [FROM THE FOLLOWING LINE REPLICATE]
'3.2.0' => ' 08/11/2013
- Ejemplo 3.-
',
'3.1.0' => ' 13/06/2013
- Ejemplo 2.-
',
'3.0.0' => ' 13/05/2013
- Ejemplo 1.-
',
// TO HERE [UNTIL THE PREVIOUS LINE]
// AN ERROR EDITING THIS FILE WILL RETURN A PHP ERROR IN YOUR CHANGELOG PAGE
);
/* end of CHANGELOG.php */